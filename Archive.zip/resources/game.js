(function () {
angular.module('ngNoughtsAndCrosses', [])
    .filter('ViewCounter', function () {
        return function (input) {    
            if (input == '-1') {                
                return '';
            }
            else {
                return input;
            }
        }
    })
    .controller('ctrl', function () {
        var vm = this;    
   
        //  Let's initialise the board here with the game status, turn, player number and some messages
        vm.ResetGame = function () {
            
            vm.Row0 = ['-1','-1','-1','-1','-1','-1','-1'];
            vm.Row1 = ['-1','-1','-1','-1','-1','-1','-1'];
            vm.Row2 = ['-1','-1','-1','-1','-1','-1','-1'];
            vm.Row3 = ['-1','-1','-1','-1','-1','-1','-1'];
            vm.Row4 = ['-1','-1','-1','-1','-1','-1','-1'];
            vm.Row5 = ['-1','-1','-1','-1','-1','-1','-1'];
            
            vm.GameOver = false;
            vm.Player = '1';
            vm.Message = '';   
            vm.TurnNumber = 0;
            vm.ShowModal = false;             
        }

        //  Event that is fired when the player takes a turn
        vm.TakeTurn = function (e) {                       
            if (!vm.GameOver) {
                //  Place the counter on the board, let's loop over the rows
                var turnTaken = false;                
                for(var i=0;i<6;i++){
                    //  TONS OF REPEATING CODE LETS CLEAR THIS UP!
                    switch(i) {
                        case 0:                            
                            if (vm.Row0[e] === '-1') {
                                vm.Row0[e] = vm.Player;
                                i=6;
                                turnTaken = true;
                            }                      
                            break;
                        case 1:                            
                            if (vm.Row1[e] === '-1') {
                                vm.Row1[e] = vm.Player;
                                i=6;
                                turnTaken = true;
                            }                      
                            break;
                        case 2:                            
                            if (vm.Row2[e] === '-1') {
                                vm.Row2[e] = vm.Player;
                                i=6;
                                turnTaken = true;
                            }                      
                            break;
                        case 3:                            
                            if (vm.Row3[e] === '-1') {
                                vm.Row3[e] = vm.Player;
                                i=6;
                                turnTaken = true;
                            }                      
                            break;
                        case 4:                            
                            if (vm.Row4[e] === '-1') {
                                vm.Row4[e] = vm.Player;
                                i=6;
                                turnTaken = true;
                            }                      
                            break;
                        case 5:                            
                            if (vm.Row5[e] === '-1') {
                                vm.Row5[e] = vm.Player;
                                i=6;
                                turnTaken = true;
                            }                      
                            break;
                    }
                }

                //  Check to see if it was a winning turn with this matrix
                if (true) {
                    //vm.Message = 'Player ' + vm.Player + ' is the winner :)';
                    //vm.GameOver = true;
                    //vm.ShowModal = true;
                }

                if (vm.GameOver) {
                    vm.GameOver = false;  
                    vm.ShowModal = true;
                }
                else if (!vm.GameOver && turnTaken) {
                    // It's the next turn then!  
                    vm.Player = (vm.Player == '1') ? '2' : '1';
                }
                
            }
        }

    })
})();